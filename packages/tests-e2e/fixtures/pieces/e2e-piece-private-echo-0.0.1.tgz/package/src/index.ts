import { createAction, createPiece, PieceAuth, Property } from '@activepieces/pieces-framework';

const echo = createAction({
  name: 'echo',
  displayName: 'Echo',
  description: 'Returns the text it receives',
  props: {
    text: Property.ShortText({ displayName: 'Text', required: true }),
  },
  async run(context) {
    return { echo: context.propsValue.text };
  },
});

export const privateEcho = createPiece({
  displayName: 'E2E Private Echo',
  description: 'A private piece that the E2E suite installs from an archive',
  auth: PieceAuth.None(),
  minimumSupportedRelease: '0.36.1',
  logoUrl: 'https://cdn.activepieces.com/pieces/webhook.svg',
  authors: [],
  actions: [echo],
  triggers: [],
});
