export declare const yocoAuth: import("@activepieces/pieces-framework").CustomAuthProperty<{
    secret_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
}>;
