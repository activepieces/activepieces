export declare const refundPaymentAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    secret_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
}>, {
    payment_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    amount: import("@activepieces/pieces-framework").NumberProperty<false>;
    reason: import("@activepieces/pieces-framework").LongTextProperty<false>;
}>;
