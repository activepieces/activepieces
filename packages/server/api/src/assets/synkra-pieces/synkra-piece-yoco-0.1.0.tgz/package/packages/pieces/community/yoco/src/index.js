"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.yoco = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const auth_1 = require("./lib/auth");
const create_checkout_action_1 = require("./lib/actions/create-checkout.action");
const get_checkout_action_1 = require("./lib/actions/get-checkout.action");
const refund_payment_action_1 = require("./lib/actions/refund-payment.action");
const payment_succeeded_trigger_1 = require("./lib/triggers/payment-succeeded.trigger");
exports.yoco = (0, pieces_framework_1.createPiece)({
    displayName: 'Yoco',
    description: 'South African card payments. Create checkout sessions, look up payments, issue refunds, and react to successful payments.',
    minimumSupportedRelease: '0.92.0',
    logoUrl: 'https://res.cloudinary.com/dewvhnks3/image/upload/v1791628900/yoco-logo_synkra.png',
    categories: [pieces_framework_1.PieceCategory.PAYMENT_PROCESSING, pieces_framework_1.PieceCategory.COMMERCE],
    auth: auth_1.yocoAuth,
    authors: ['synkra'],
    actions: [
        create_checkout_action_1.createCheckoutAction,
        get_checkout_action_1.getCheckoutAction,
        refund_payment_action_1.refundPaymentAction,
    ],
    triggers: [payment_succeeded_trigger_1.paymentSucceededTrigger],
});
//# sourceMappingURL=index.js.map