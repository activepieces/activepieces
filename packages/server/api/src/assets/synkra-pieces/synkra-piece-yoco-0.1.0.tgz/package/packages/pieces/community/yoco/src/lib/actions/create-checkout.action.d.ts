export declare const createCheckoutAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    secret_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
}>, {
    amount: import("@activepieces/pieces-framework").NumberProperty<true>;
    currency: import("@activepieces/pieces-framework").StaticDropdownProperty<string, true>;
    success_url: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    cancel_url: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    failure_url: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    reference: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    metadata_json: import("@activepieces/pieces-framework").JsonProperty<false>;
}>;
