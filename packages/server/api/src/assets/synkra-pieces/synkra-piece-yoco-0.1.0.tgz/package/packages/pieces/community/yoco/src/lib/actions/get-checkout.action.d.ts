export declare const getCheckoutAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    secret_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
}>, {
    checkout_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
