import { HttpMethod } from '@activepieces/pieces-common';
export declare const YOCO_BASE = "https://online.yoco.com/v1";
export declare function yocoRequest<T>(params: {
    secretKey: string;
    method: HttpMethod;
    path: string;
    query?: Record<string, string | number>;
    body?: Record<string, unknown>;
}): Promise<T>;
