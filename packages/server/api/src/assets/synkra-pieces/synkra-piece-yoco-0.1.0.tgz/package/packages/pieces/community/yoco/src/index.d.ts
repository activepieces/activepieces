export declare const yoco: import("@activepieces/pieces-framework").Piece<import("@activepieces/pieces-framework").CustomAuthProperty<{
    secret_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
}>>;
