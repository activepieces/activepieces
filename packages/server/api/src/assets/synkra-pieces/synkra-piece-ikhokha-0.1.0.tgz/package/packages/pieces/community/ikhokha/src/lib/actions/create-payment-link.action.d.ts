export declare const createPaymentLinkAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    app_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    app_secret: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {
    amount: import("@activepieces/pieces-framework").NumberProperty<true>;
    reference: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    description: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    customer_email: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    callback_url: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
