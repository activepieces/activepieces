"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ikhokha = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const auth_1 = require("./lib/auth");
const create_payment_link_action_1 = require("./lib/actions/create-payment-link.action");
const get_payment_action_1 = require("./lib/actions/get-payment.action");
const refund_payment_action_1 = require("./lib/actions/refund-payment.action");
const payment_received_trigger_1 = require("./lib/triggers/payment-received.trigger");
exports.ikhokha = (0, pieces_framework_1.createPiece)({
    displayName: 'iKhokha',
    description: 'South African card and mobile payments. Create payment links, look up payments, issue refunds, and react to incoming payments.',
    minimumSupportedRelease: '0.92.0',
    logoUrl: 'https://res.cloudinary.com/dewvhnks3/image/upload/v1791629000/ikhokha-logo_synkra.png',
    categories: [pieces_framework_1.PieceCategory.PAYMENT_PROCESSING, pieces_framework_1.PieceCategory.COMMERCE],
    auth: auth_1.ikhokhaAuth,
    authors: ['synkra'],
    actions: [
        create_payment_link_action_1.createPaymentLinkAction,
        get_payment_action_1.getPaymentAction,
        refund_payment_action_1.refundPaymentAction,
    ],
    triggers: [payment_received_trigger_1.paymentReceivedTrigger],
});
//# sourceMappingURL=index.js.map