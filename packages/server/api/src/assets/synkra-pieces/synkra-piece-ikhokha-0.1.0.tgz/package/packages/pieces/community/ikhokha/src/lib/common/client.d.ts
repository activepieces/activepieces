import { HttpMethod } from '@activepieces/pieces-common';
export type IkhokhaAuth = {
    app_id: string;
    app_secret: string;
    sandbox?: boolean;
};
/**
 * iKhokha signs each request. The signing string is:
 *   METHOD + "\n" + PATH + "\n" + BODY_JSON
 * HMAC-SHA256 with the app secret, base64 encoded.
 */
export declare function ikhokhaRequest<T>(params: {
    auth: IkhokhaAuth;
    method: HttpMethod;
    path: string;
    body?: Record<string, unknown>;
    query?: Record<string, string | number>;
}): Promise<T>;
