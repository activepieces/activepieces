export declare const ikhokha: import("@activepieces/pieces-framework").Piece<import("@activepieces/pieces-framework").CustomAuthProperty<{
    app_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    app_secret: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>>;
