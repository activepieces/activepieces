import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const paymentReceivedTrigger: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").CustomAuthProperty<{
    app_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    app_secret: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").CustomAuthProperty<{
    app_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    app_secret: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").CustomAuthProperty<{
    app_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    app_secret: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").CustomAuthProperty<{
    app_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    app_secret: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {}>;
