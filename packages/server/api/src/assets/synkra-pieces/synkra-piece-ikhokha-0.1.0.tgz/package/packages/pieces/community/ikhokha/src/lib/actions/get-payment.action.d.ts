export declare const getPaymentAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    app_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    app_secret: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {
    payment_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
