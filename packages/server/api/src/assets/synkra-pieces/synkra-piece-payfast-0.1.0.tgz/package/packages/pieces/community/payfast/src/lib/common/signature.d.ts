/**
 * PayFast signature algorithm.
 * 1. Take all fields except signature.
 * 2. URL-encode each value (spaces become +).
 * 3. Join as key=value pairs with & in the original order.
 * 4. If a passphrase is set, append &passphrase=<urlencoded-passphrase>.
 * 5. MD5 hash the entire string, hex output.
 */
export declare function payfastSignature(data: Record<string, string | number | undefined | null>, passphrase: string): string;
export declare function payfastBaseUrl(sandbox: boolean): string;
export declare function payfastApiBaseUrl(sandbox: boolean): string;
