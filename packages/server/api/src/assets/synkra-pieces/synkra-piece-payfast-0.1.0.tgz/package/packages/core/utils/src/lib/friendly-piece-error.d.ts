export declare const formatPieceError: (error: unknown, options?: FormatPieceErrorOptions) => FriendlyPieceError;
export declare const tryParseFriendlyPieceError: (value: unknown) => FriendlyPieceError | null;
export type FriendlyPieceError = {
    __apErrorVersion: 1;
    message: string;
    errorName?: string;
    status?: number;
    responseBody?: unknown;
    responseHeaders?: Record<string, unknown>;
    requestBody?: unknown;
    requestUrl?: string;
    requestMethod?: string;
    apiMessage?: string;
    raw?: string;
};
type FormatPieceErrorOptions = {
    raw?: string;
};
export {};
