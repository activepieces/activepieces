export declare const payfast: import("@activepieces/pieces-framework").Piece<import("@activepieces/pieces-framework").CustomAuthProperty<{
    merchant_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    merchant_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    passphrase: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    api_user: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    api_password: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>>;
