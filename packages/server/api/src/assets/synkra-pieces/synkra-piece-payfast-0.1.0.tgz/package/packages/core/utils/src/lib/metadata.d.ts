import * as z from 'zod/mini';
/**
 * Flexible key-value record type for storing arbitrary data
 *
 * The Metadata type provides a flexible way to store additional information
 * on various entities without requiring schema changes. It can be used for:
 * - Custom categorization
 * - Integration with external systems
 * - Environment-specific configurations
 * - Analytics and tracking information
 *
 * @example
 * // Example metadata for a project
 * const metadata = {
 *   department: "marketing",
 *   priority: 1,
 *   customField: "customValue"
 * }
 */
export declare const Metadata: z.ZodMiniRecord<z.ZodMiniString<string>, z.ZodMiniUnknown>;
export type Metadata = z.infer<typeof Metadata>;
