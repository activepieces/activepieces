import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const paymentCompleteTrigger: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").CustomAuthProperty<{
    merchant_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    merchant_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    passphrase: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    api_user: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    api_password: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").CustomAuthProperty<{
    merchant_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    merchant_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    passphrase: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    api_user: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    api_password: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").CustomAuthProperty<{
    merchant_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    merchant_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    passphrase: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    api_user: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    api_password: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").CustomAuthProperty<{
    merchant_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    merchant_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    passphrase: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    api_user: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    api_password: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {}>;
