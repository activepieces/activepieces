export declare const refundPaymentAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    merchant_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    merchant_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    passphrase: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    api_user: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    api_password: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {
    transaction_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    amount: import("@activepieces/pieces-framework").NumberProperty<false>;
    reason: import("@activepieces/pieces-framework").LongTextProperty<false>;
    notify_buyer: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
