import { HttpMethod } from '@activepieces/pieces-common';
export type PayfastAuth = {
    merchant_id: string;
    merchant_key: string;
    passphrase: string;
    api_user?: string;
    api_password?: string;
    sandbox?: boolean;
};
/**
 * PayFast API requests use a "merchant-id" + "version" + "timestamp" + "signature" scheme.
 * Signature = MD5(querystring-of-params-with-passphrase).
 * Headers carry merchant-id and signature.
 */
export declare function payfastApiRequest<T>(params: {
    auth: PayfastAuth;
    method: HttpMethod;
    path: string;
    query?: Record<string, string | number>;
    body?: Record<string, unknown>;
}): Promise<T>;
