export declare const createPaymentAction: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").CustomAuthProperty<{
    merchant_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    merchant_key: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    passphrase: import("@activepieces/pieces-framework").SecretTextProperty<true>;
    api_user: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    api_password: import("@activepieces/pieces-framework").SecretTextProperty<false>;
    sandbox: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>, {
    amount: import("@activepieces/pieces-framework").NumberProperty<true>;
    item_name: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    item_description: import("@activepieces/pieces-framework").LongTextProperty<false>;
    reference: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    email: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    first_name: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    last_name: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    return_url: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    cancel_url: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    notify_url: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    email_confirmation: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
