"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.payfast = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const auth_1 = require("./lib/auth");
const create_payment_action_1 = require("./lib/actions/create-payment.action");
const get_transaction_action_1 = require("./lib/actions/get-transaction.action");
const refund_payment_action_1 = require("./lib/actions/refund-payment.action");
const payment_complete_trigger_1 = require("./lib/triggers/payment-complete.trigger");
exports.payfast = (0, pieces_framework_1.createPiece)({
    displayName: 'PayFast',
    description: 'South African payment gateway. Create payment links, process refunds, and react to completed payments in real time.',
    minimumSupportedRelease: '0.92.0',
    logoUrl: 'https://res.cloudinary.com/dewvhnks3/image/upload/v1791628800/payfast-logo_synkra.png',
    categories: [pieces_framework_1.PieceCategory.PAYMENT_PROCESSING, pieces_framework_1.PieceCategory.COMMERCE],
    auth: auth_1.payfastAuth,
    authors: ['synkra'],
    actions: [
        create_payment_action_1.createPaymentAction,
        get_transaction_action_1.getTransactionAction,
        refund_payment_action_1.refundPaymentAction,
    ],
    triggers: [payment_complete_trigger_1.paymentCompleteTrigger],
});
//# sourceMappingURL=index.js.map