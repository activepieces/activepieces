"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.discord = void 0;
const tslib_1 = require("tslib");
const pieces_common_1 = require("@activepieces/pieces-common");
const pieces_framework_1 = require("@activepieces/pieces-framework");
const shared_1 = require("@activepieces/shared");
const add_role_to_member_1 = require("./lib/actions/add-role-to-member");
const find_channel_1 = require("./lib/actions/find-channel");
const find_guild_member_1 = require("./lib/actions/find-guild-member");
const remove_member_from_guild_1 = require("./lib/actions/remove-member-from-guild");
const remove_role_from_member_1 = require("./lib/actions/remove-role-from-member");
const rename_channel_1 = require("./lib/actions/rename-channel");
const create_channel_1 = require("./lib/actions/create-channel");
const delete_channel_1 = require("./lib/actions/delete-channel");
const send_approval_message_1 = require("./lib/actions/send-approval-message");
const send_message_webhook_1 = require("./lib/actions/send-message-webhook");
const new_message_1 = require("./lib/triggers/new-message");
const remove_ban_from_user_1 = require("./lib/actions/remove-ban-from-user");
const create_guild_role_1 = require("./lib/actions/create-guild-role");
const delete_guild_role_1 = require("./lib/actions/delete-guild-role");
const ban_a_guild_member_1 = require("./lib/actions/ban-a-guild-member");
const new_member_1 = require("./lib/triggers/new-member");
const send_message_with_bot_1 = require("./lib/actions/send-message-with-bot");
const auth_1 = require("./lib/auth");
const markdown = `
To obtain a token, follow these steps:
1. Go to https://discord.com/developers/applications
2. Click on Application (or create one if you don't have one)
3. Click on Bot
4. Copy the token
`;
exports.discord = (0, pieces_framework_1.createPiece)({
    displayName: 'Testing Before New CI Discord',
    description: 'Instant messaging and VoIP social platform',
    minimumSupportedRelease: '0.30.0',
    logoUrl: 'https://cdn.activepieces.com/pieces/discord.png',
    categories: [shared_1.PieceCategory.COMMUNICATION],
    auth: auth_1.discordAuth,
    actions: [
        send_message_with_bot_1.sendMessageWithBot,
        send_message_webhook_1.discordSendMessageWebhook,
        send_approval_message_1.discordSendApprovalMessage,
        add_role_to_member_1.discordAddRoleToMember,
        remove_role_from_member_1.discordRemoveRoleFromMember,
        remove_member_from_guild_1.discordRemoveMemberFromGuild,
        find_guild_member_1.discordFindGuildMemberByUsername,
        rename_channel_1.discordRenameChannel,
        create_channel_1.discordCreateChannel,
        delete_channel_1.discordDeleteChannel,
        find_channel_1.discordFindChannel,
        remove_ban_from_user_1.discordRemoveBanFromUser,
        create_guild_role_1.discordCreateGuildRole,
        delete_guild_role_1.discordDeleteGuildRole,
        ban_a_guild_member_1.discordBanGuildMember,
        (0, pieces_common_1.createCustomApiCallAction)({
            auth: auth_1.discordAuth,
            baseUrl: () => {
                return 'https://discord.com/api/v9';
            },
            authMapping: (auth) => tslib_1.__awaiter(void 0, void 0, void 0, function* () {
                return {
                    Authorization: `Bot ${auth.secret_text}`,
                };
            }),
        }),
    ],
    authors: [
        'creed983',
        'TaskMagicKyle',
        'karimkhaleel',
        'Abdallah-Alwarawreh',
        'kishanprmr',
        'MoShizzle',
        'AbdulTheActivePiecer',
        'khaledmashaly',
        'abuaboud',
        'tintinthedev',
        'AshotZaqoyan'
    ],
    triggers: [new_message_1.newMessage, new_member_1.newMember],
});
//# sourceMappingURL=index.js.map