export declare const discordSendApprovalMessage: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    content: import("@activepieces/pieces-framework").LongTextProperty<true>;
    channel: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
}>;
//# sourceMappingURL=send-approval-message.d.ts.map