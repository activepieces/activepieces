export declare const discordSendMessageWebhook: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").PieceAuthProperty, {
    webhook_url: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    username: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    content: import("@activepieces/pieces-framework").LongTextProperty<true>;
    avatar_url: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    embeds: import("@activepieces/pieces-framework").JsonProperty<false>;
    tts: import("@activepieces/pieces-framework").CheckboxProperty<false>;
}>;
//# sourceMappingURL=send-message-webhook.d.ts.map