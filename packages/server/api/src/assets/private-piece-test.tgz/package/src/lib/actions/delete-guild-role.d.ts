export declare const discordDeleteGuildRole: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    guild_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    role_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    deletion_reason: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=delete-guild-role.d.ts.map