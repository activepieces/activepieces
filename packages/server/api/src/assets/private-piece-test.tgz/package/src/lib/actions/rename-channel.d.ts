export declare const discordRenameChannel: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    channel_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    name: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=rename-channel.d.ts.map