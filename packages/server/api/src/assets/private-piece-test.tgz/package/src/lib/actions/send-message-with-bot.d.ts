export declare const sendMessageWithBot: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    channel_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    message: import("@activepieces/pieces-framework").LongTextProperty<false>;
    files: import("@activepieces/pieces-framework").ArrayProperty<false>;
}>;
//# sourceMappingURL=send-message-with-bot.d.ts.map