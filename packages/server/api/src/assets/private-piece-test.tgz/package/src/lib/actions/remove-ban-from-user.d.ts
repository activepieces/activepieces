export declare const discordRemoveBanFromUser: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    guild_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    user_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    unban_reason: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=remove-ban-from-user.d.ts.map