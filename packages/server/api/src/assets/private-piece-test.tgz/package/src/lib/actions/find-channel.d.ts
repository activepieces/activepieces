export declare const discordFindChannel: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    guild_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    name: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=find-channel.d.ts.map