export declare const discordRemoveMemberFromGuild: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    guild_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    user_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=remove-member-from-guild.d.ts.map