import { TriggerStrategy } from '@activepieces/pieces-framework';
export declare const newMember: import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.WEBHOOK, import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    limit: import("@activepieces/pieces-framework").NumberProperty<false>;
    guildId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.POLLING, import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    limit: import("@activepieces/pieces-framework").NumberProperty<false>;
    guildId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.MANUAL, import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    limit: import("@activepieces/pieces-framework").NumberProperty<false>;
    guildId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}> | import("@activepieces/pieces-framework").ITrigger<TriggerStrategy.APP_WEBHOOK, import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    limit: import("@activepieces/pieces-framework").NumberProperty<false>;
    guildId: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=new-member.d.ts.map