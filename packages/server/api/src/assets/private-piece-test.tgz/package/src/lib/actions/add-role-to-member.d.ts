export declare const discordAddRoleToMember: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    guild_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    user_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    role_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
}>;
//# sourceMappingURL=add-role-to-member.d.ts.map