export declare const discordCreateGuildRole: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    guild_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    role_name: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    role_color: import("@activepieces/pieces-framework").ShortTextProperty<false>;
    display_separated: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    role_mentionable: import("@activepieces/pieces-framework").CheckboxProperty<false>;
    creation_reason: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=create-guild-role.d.ts.map