export declare const discordFindGuildMemberByUsername: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    guild_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    shortText: import("@activepieces/pieces-framework").ShortTextProperty<true>;
}>;
//# sourceMappingURL=find-guild-member.d.ts.map