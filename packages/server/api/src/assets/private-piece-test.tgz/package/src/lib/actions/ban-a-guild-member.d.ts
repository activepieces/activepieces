export declare const discordBanGuildMember: import("@activepieces/pieces-framework").IAction<import("@activepieces/pieces-framework").SecretTextProperty<true>, {
    guild_id: import("@activepieces/pieces-framework").DropdownProperty<string, true, import("@activepieces/pieces-framework").SecretTextProperty<true>>;
    user_id: import("@activepieces/pieces-framework").ShortTextProperty<true>;
    ban_reason: import("@activepieces/pieces-framework").ShortTextProperty<false>;
}>;
//# sourceMappingURL=ban-a-guild-member.d.ts.map