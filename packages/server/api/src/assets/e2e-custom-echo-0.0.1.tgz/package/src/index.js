"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.echoPiece = void 0;
const pieces_framework_1 = require("@activepieces/pieces-framework");
const echo_1 = require("./lib/actions/echo");
exports.echoPiece = (0, pieces_framework_1.createPiece)({
    displayName: "E2E Custom Echo",
    description: "Minimal no-auth custom piece used by the e2e smoke test to verify tar.gz custom-piece installation and execution.",
    auth: pieces_framework_1.PieceAuth.None(),
    minimumSupportedRelease: '0.0.0',
    logoUrl: "https://cdn.activepieces.com/pieces/new-core/json-helper.svg",
    authors: [],
    actions: [echo_1.echo],
    triggers: [],
});
